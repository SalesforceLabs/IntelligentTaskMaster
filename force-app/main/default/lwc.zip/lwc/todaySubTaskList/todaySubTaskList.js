import { LightningElement, api } from 'lwc';

export default class TodaySubTaskList extends LightningElement {
    
    @api
    taskListJson;
}